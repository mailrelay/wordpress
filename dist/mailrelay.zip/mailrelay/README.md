# Mailrelay - Wordpress plugin

Easily sync your wordpress users with [Mailrelay.com][1].

# Installation

The easiest way to install is to download the zip file directly from [our website][2] and install in WP Admin -> Plugins -> Add new -> Upload.

If you want to use the latest version in git, clone it in wp-content/plugins/mailrelay

[1]: http://mailrelay.com/
[2]: http://mailrelay.com/es/herramientas-plugins